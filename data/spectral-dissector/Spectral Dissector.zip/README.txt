SPECTRAL DISSECTOR
==================

作品 / Work:      SPECTRAL DISSECTOR
设备 / Device:    Spectral Separator.amxd
版本 / Version:   26.09.12

曹浩轩（算法与架构）与闫开（新版实现与 UI）共同创作的作品。
A work co-created by Cao Haoxuan (algorithm and architecture) and Yan Kai
(implementation and UI of the current version).

说明
----
· 包内设备名为 Spectral Separator.amxd，作品名为 SPECTRAL DISSECTOR，内部工程名同为
  Spectral Dissector —— 三者指同一件作品。
· 在 Max 9.0.3 (x64) 中保存；包内未声明最低 Live / Max 版本要求。
· 只使用 Max/MSP 与 Live 自带对象（pfft~、plugin~、plugout~、live.* 等），
  不含第三方外部对象。
· 运行需要 Max for Live；编辑 patcher 需自备 Max / Max for Live 环境。

许可
----
个人与商业作品可免费使用，可自用修改；禁止再分发、转售。完整条款见 LICENSE.txt。
Free for personal and commercial use; modification for your own use permitted;
redistribution and resale prohibited. Full terms in LICENSE.txt.

反馈与授权申请 / Feedback and permission requests: caohaoxuan0624@gmail.com
